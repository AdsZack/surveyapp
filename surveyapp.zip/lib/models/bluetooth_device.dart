class ControlButton {
  final String buttonName;
  final Function() onTap;

  ControlButton({required this.buttonName, required this.onTap});
}