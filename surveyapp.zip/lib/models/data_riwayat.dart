class DataRiwayat {
  final String rute;
  // final bool status;
  final String status;

  DataRiwayat({required this.rute, required this.status});
}
